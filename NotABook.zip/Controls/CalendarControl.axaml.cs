using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace NotABook;

public partial class CalendarControl : UserControl
{
    public CalendarControl()
    {
        InitializeComponent();
    }
}